# Diseño público de Brasa Viva

## Dirección visual

Identidad gastronómica cálida: crema, rojo brasa, carbón y tonos cobre. Titulares serif editoriales,
texto sans para lectura y formularios. Tokens y estilos en `apps/web/app/public.css`, acotados a
`.public-shell`; el panel administrativo conserva su diseño. Marca con símbolo de fuego, navegación
activa y menú móvil desplegable con cierre por Escape. Targets de al menos 44 px y movimiento reducido.

## Recorrido

Inicio → elegir sucursal → explorar menú → carrito → confirmar datos → pedido registrado → WhatsApp.
Inicio presenta antojos, promociones, tres pasos para pedir, ambiente y preguntas frecuentes.
Menú conserva selección explícita de sucursal, filtros, búsqueda y precios suministrados por Nest.
Promociones, sucursales, producto, nosotros y contacto comparten jerarquía y componentes visuales.
Los detalles de sucursal muestran la hora local almacenada, servicios y contacto; no se simula
apertura actual ni disponibilidad. Maps busca la dirección; no promete coordenadas verificadas.

## Imágenes

Generación integrada con la habilidad `imagegen`, sin API/CLI adicional. Las imágenes originales
se inspeccionaron y los archivos locales finales se optimizaron a WebP con calidad 82:

- `apps/web/public/images/brasa-viva-fire-v2.webp`: 1536 × 1024, aproximadamente 231 KiB.
- `apps/web/public/images/brasa-viva-atmosphere-v1.webp`: 1536 × 1024, aproximadamente 214 KiB.
- `apps/web/public/images/brasa-viva-broaster-v1.webp`: 1536 × 1024, aproximadamente 278 KiB.
- `apps/web/public/images/brasa-viva-sharing-v1.webp`: 1536 × 1024, aproximadamente 268 KiB.

Las imágenes de ambiente están rotuladas como ilustrativas; no documentan una sucursal existente.
Las tarjetas de presentación no contienen precios, porciones o descuentos inventados.
Para publicar fotos reales, reemplaza los assets ilustrativos por material aprobado del negocio
y revisa el alt y el rótulo. Los productos usan exclusivamente su imagen configurada en catálogo.
Sin foto o ante un error se muestra “Foto próximamente”, sin atribuir una foto de otro plato.

`ProductPhoto` utiliza next/image y admite assets locales de `/images/` o imágenes del bucket
público del origen `NEXT_PUBLIC_SUPABASE_URL`. Next tiene el mismo allowlist y WebP/AVIF.
Los enlaces de imágenes de hosts externos requieren una decisión explícita sobre origen/configuración.
Reinicia Next después de cambiar la configuración de imágenes.

## Prompts finales

### Portada

Use case: photorealistic-natural. Asset type: wide restaurant website hero photograph, landscape 3:2. Primary request: incredibly appetizing charcoal rotisserie chicken on a dark ceramic platter with golden French fries, small bowls of llajua tomato chili sauce and fresh salad, on a deep dark walnut restaurant table. Food dominates the right two thirds; left third is quiet charcoal shadow, usable for overlaid large white headline. Warm amber sidelight, real crisp golden skin with subtle char, delicate steam, a little out of focus ember fire behind, editorial premium food photography, 50mm lens, believable textures and proportions, deep natural blacks and copper highlights, no plastic sheen. Scene evokes a cozy Cochabamba chicken restaurant, no landmarks. No lettering, watermark, logos, collage, graphics, UI or fake awards. This is illustrative marketing imagery, not documentation of a real establishment.

### Ambiente

Use case: photorealistic-natural. Asset type: restaurant website atmosphere illustration, landscape 3:2. Primary request: a warm, believable contemporary neighborhood chicken restaurant interior inspired by Cochabamba Bolivia, welcoming communal wood tables, bentwood chairs, reddish terracotta plaster, dark green leather booth, soft amber pendant lights, subtle daylight through tall windows, leafy potted plants, open counter with warm grill light in distant background. Editorial architectural photography, eye level, 35mm, natural perspective, textured materials, cozy and attainable rather than luxury hotel. Clear foreground table on right, tasteful red napkins and ceramic plates, no people or food closeup, no text or signage, no logos, no watermark. This is a conceptual illustrative scene, not a real branch photo. Warm cream, rust red, walnut and charcoal palette, landscape frame.

## Verificación del 2026-10-06

- `pnpm lint`, `pnpm typecheck`, `pnpm test`: pasan; 46 pruebas (22 API, 17 web, 7 contratos).
- Nuevos casos verifican orígenes seguros de fotos y representación de horas sin cambios de zona.
- Playwright incorpora navegación móvil, Escape, página activa y las ocho vistas públicas a
  375/430/768/1440 px. Los siete tests se descubren correctamente.
- `pnpm build` falla en Turbopack al abrir un puerto: EPERM. `pnpm --filter @brasa-viva/web test:e2e`
  no inicia su fixture en 4101 por EPERM. Next dev tampoco puede escuchar en 3102. Estos checks
  permanecen pendientes en la terminal local/CI; no se afirma que E2E haya pasado.
- Se revisaron capturas estáticas de inicio en escritorio/móvil y menú móvil con Chrome CLI,
  componentes React renderizados a HTML y CSS real compilado. Se ajustó contraste del hero móvil.
  Esta revisión no verifica hidratación React, navegación interactiva ni integración con Supabase.
  La automatización de Chrome con Playwright también falló por permisos de sockets (SIGTRAP).

Capturas revisadas: [inicio escritorio](design-previews/public-home-desktop.webp),
[inicio móvil](design-previews/public-home-mobile.webp) y [menú móvil](design-previews/public-menu-mobile.webp).
Se renderizaron con fixtures de catálogo; las imágenes de portada y ambiente son los assets finales.

## Refinamiento del 2026-10-09

Portada dividida en componentes de `features/home`, con estilos propios en `home.css`:
hero editorial, mosaico asimétrico de antojos, bloque para compartir, pasos de pedido y ambiente
con fotos superpuestas. Crema, rojo brasa y carbón incorporan cobre y oliva. Las introducciones
de menú, promociones, sucursales, nosotros y contacto muestran fotografía en escritorio y
priorizan el contenido en móvil. Las imágenes del catálogo siguen procediendo de sus datos.

La barra inferior móvil facilita cambiar de página; el carrito flotante queda por encima.
Los enlaces generales al menú retoman la sucursal del carrito después de hidratarlo, sin
sobrescribir una selección explícita. Los enlaces del producto conservan búsqueda y categoría
para el regreso al menú. La búsqueda acepta términos con o sin tildes.

### Nuevos prompts finales

**Broaster:** Use case: photorealistic-natural. Asset type: restaurant website editorial card, landscape 3:2. An irresistible close-up of authentic golden crispy broaster chicken pieces on an ivory ceramic plate with thick golden fries, a small ceramic bowl of red Bolivian llajua and fresh green herb accents, warm dark walnut tabletop, folded olive green linen napkin. Natural side light, cinematic warm highlights, meticulous crunchy batter texture, real food photography, shallow depth of field, 50mm lens. Food centered and fills most of frame for responsive cropping. Sophisticated restaurant editorial, warm cream, rust, honey gold, deep olive palette. No text, branding, logos, watermark or collage. Illustrative food styling, no representation of a specific real menu item.

**Compartir:** Use case: photorealistic-natural. Asset type: restaurant website lifestyle editorial photograph, landscape 3:2. An inviting shared lunch on a beautifully worn walnut table in a warm Cochabamba-inspired neighborhood restaurant. A generous platter of rotisserie chicken with crispy broaster pieces, golden fries, small bowls of tomato llajua and salad, simple cream ceramic plates, amber drinks without brands. Two natural adult hands entering opposite edges to serve food, faces out of frame, anatomically realistic hands. Overhead three-quarter composition, food sharp centered, organic candid moment with natural afternoon sidelight and gentle shadows, premium editorial food photography, warm amber, terracotta, cream and olive linen. Genuine textures, no plastic or CGI appearance. No text, logos, price labels, watermark or collage. Illustrative concept, not a photograph of an actual establishment or specific offer.

### Validación

- Lint, TypeScript y las 51 pruebas unitarias pasan (22 API, 22 web, 7 contratos).
- Playwright descubre nueve escenarios, incluyendo conservación de filtros/sucursal y separación
  entre los accesos móviles y el carrito. Su ejecución queda bloqueada por `listen EPERM` en
  el puerto 4101 del fixture. El build falla por la misma restricción de puertos en Turbopack.
- Revisión estática de inicio a 375, 430, 768 y 1440 px y menú en escritorio con React y CSS real.
  Se usaron fixtures aislados, sin acceso a la base remota. No prueba hidratación ni navegación
  interactiva. Tampoco se midieron Core Web Vitals o Lighthouse.

Capturas: [inicio escritorio](design-previews/public-home-desktop-v2.webp),
[inicio móvil](design-previews/public-home-mobile-v2.webp),
[inicio tablet](design-previews/public-home-tablet-v2.webp) y
[menú escritorio](design-previews/public-menu-desktop-v2.webp).
La captura alta de escritorio usa un viewport extendido, por lo que el espacio antes del footer
puede ser mayor que en una ventana habitual.

## QA antes de publicar

La revisión del 9–12 de octubre extiende esta identidad al carrito y al formulario de pedido,
añade pasos de compra y sucursales reales en portada, conserva filtros/orden en URL y mejora
metadata y accesibilidad. Consulta [diagnóstico, Skills, capturas y verificaciones](STOREFRONT_REVIEW.md)
para el estado más reciente; los resultados históricos anteriores corresponden a sus respectivas fechas.

Ejecuta `pnpm build` y `pnpm test:e2e` en un entorno que permita sockets. Revisa con teclado,
zoom 200%, teléfonos reales y Safari: menú móvil, cambio de sucursal, filtros, carga/errores de
imágenes y recorrido del pedido. Comprueba fotos desde Storage con el proyecto configurado.
No confundir las capturas con evidencia de un lanzamiento validado.
